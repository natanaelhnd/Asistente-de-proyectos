# Optimizador de Cortes

Sube `index.html` a la raíz del repositorio de GitHub Pages. Los PDF se paginan por lances completos, con márgenes de impresión.
